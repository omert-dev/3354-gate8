# Calendar Software

A comprehensive calendar application with multiple views, event management, and advanced features.

## Features

### 📅 Views
- **Monthly View**: Display all days in a month with event snippets
- **Weekly View**: Show 7-day layout with event details
- **Daily View**: Detailed view of events sorted by time
- **Agenda View**: List of all future events

### 🎯 Event Management
- ✅ Add events with start and end times
- ✅ Time conflict detection and warnings
- ✅ Weekly recurring events
- ✅ Edit and delete existing events
- ✅ Event categories with color coding
- ✅ Custom category management

### 🎨 Visual Features
- ✅ Special colors for weekends and holidays
- ✅ Responsive design for all screen sizes
- ✅ Modern, intuitive interface
- ✅ Color-coded event categories

### 💾 Data Persistence
- ✅ Local storage for events and categories
- ✅ Data persists between browser sessions

## Getting Started

1. **Open the Application**
   - Simply open `index.html` in your web browser
   - No installation or setup required

2. **Navigation**
   - Use the arrow buttons to navigate between months/weeks/days
   - Click on view buttons (Month, Week, Day, Agenda) to switch views
   - Click on any day to jump to daily view

3. **Adding Events**
   - Click the "Add Event" button
   - Fill in event details (title, description, dates, times)
   - Choose a category or create a new one
   - Enable "Weekly Recurring" for repeating events
   - Save the event

4. **Managing Categories**
   - Click the "Categories" button to manage event categories
   - Add new categories with custom colors
   - Delete unused categories

## Usage Guide

### Monthly View
- Shows a traditional calendar grid
- Event snippets appear on each day
- Click on any day to view details
- Weekends and holidays are highlighted

### Weekly View
- Displays 7 days in a horizontal layout
- Shows time slots for better scheduling
- Click on any day to switch to daily view

### Daily View
- Detailed view of a single day
- Events sorted by start time
- Perfect for detailed scheduling

### Agenda View
- Lists all future events
- Grouped by date
- Great for overview of upcoming events

### Event Management
- **Adding Events**: Click "Add Event" and fill in the form
- **Editing Events**: Click on any event to edit it
- **Deleting Events**: Edit an event and click "Delete"
- **Recurring Events**: Check "Weekly Recurring" and specify duration

### Time Conflicts
- The system automatically detects overlapping events
- You'll be warned about conflicts before saving
- Choose to proceed anyway or modify the timing

### Categories
- Default categories: General, Work, Personal, Health
- Create custom categories with your own colors
- Events are color-coded by category

## Technical Details

### Browser Compatibility
- Modern browsers (Chrome, Firefox, Safari, Edge)
- Responsive design works on desktop and mobile
- Uses modern JavaScript (ES6+)

### Data Storage
- Events and categories stored in browser's localStorage
- Data persists between sessions
- No server required - fully client-side

### File Structure
```
Calendar/
├── index.html          # Main HTML file
├── styles.css          # CSS styling
├── script.js           # JavaScript functionality
└── README.md           # This file
```

## Customization

### Adding Holidays
Edit the `isHoliday()` method in `script.js` to add more holidays:

```javascript
isHoliday(date) {
    const month = date.getMonth();
    const day = date.getDate();
    
    // Add your holidays here
    if (month === 0 && day === 1) return true; // New Year's Day
    if (month === 6 && day === 4) return true; // Independence Day
    // Add more holidays...
    
    return false;
}
```

### Styling
- Modify `styles.css` to change colors, fonts, and layout
- All colors are defined as CSS variables for easy customization
- Responsive breakpoints can be adjusted

### Features
- The code is well-commented and modular
- Easy to extend with additional features
- Event system allows for custom functionality

## Future Enhancements

Potential features that could be added:
- Event alerts/notifications
- Event sharing between users
- Import/export functionality
- More recurring patterns (daily, monthly, yearly)
- Event search and filtering
- Calendar themes
- Integration with external calendar services

## Support

This is a standalone web application that runs entirely in your browser. No external dependencies or server setup required.

Enjoy using your new calendar software! 📅✨
