// Calendar Software - Main JavaScript File

class CalendarApp {
    constructor() {
        this.currentDate = new Date();
        this.currentView = 'monthly';
        this.events = this.loadEvents();
        this.categories = this.loadCategories();
        this.editingEvent = null;

        this.initializeApp();
        this.setupEventListeners();
        this.renderCurrentView();
    }

    // Initialize the application
    initializeApp() {
        this.updateCurrentDateDisplay();
        this.populateTimeSlots();
        this.populateCategories();
        this.loadHolidays();
    }

    // Setup all event listeners
    setupEventListeners() {
        // Navigation buttons
        document.getElementById('prevBtn').addEventListener('click', () => this.navigate(-1));
        document.getElementById('nextBtn').addEventListener('click', () => this.navigate(1));

        // View buttons
        document.getElementById('monthView').addEventListener('click', () => this.switchView('monthly'));
        document.getElementById('weekView').addEventListener('click', () => this.switchView('weekly'));
        document.getElementById('dayView').addEventListener('click', () => this.switchView('daily'));
        document.getElementById('agendaView').addEventListener('click', () => this.switchView('agenda'));

        // Action buttons
        document.getElementById('addEventBtn').addEventListener('click', () => this.openEventModal());
        document.getElementById('categoriesBtn').addEventListener('click', () => this.openCategoriesModal());

        // Modal controls
        document.getElementById('closeModal').addEventListener('click', () => this.closeEventModal());
        document.getElementById('closeCategoriesModal').addEventListener('click', () => this.closeCategoriesModal());
        document.getElementById('closeConflictModal').addEventListener('click', () => this.closeConflictModal());

        // Event form
        document.getElementById('eventForm').addEventListener('submit', (e) => this.handleEventSubmit(e));
        document.getElementById('cancelEvent').addEventListener('click', () => this.closeEventModal());
        document.getElementById('deleteEvent').addEventListener('click', () => this.deleteCurrentEvent());

        // Recurring events
        document.getElementById('isRecurring').addEventListener('change', (e) => {
            document.getElementById('recurringWeeks').disabled = !e.target.checked;
        });

        // Categories
        document.getElementById('addCategoryBtn').addEventListener('click', () => this.addCategory());

        // Conflict modal
        document.getElementById('proceedAnyway').addEventListener('click', () => this.proceedWithConflict());
        document.getElementById('cancelConflict').addEventListener('click', () => this.closeConflictModal());

        // Click outside modal to close
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeEventModal();
                this.closeCategoriesModal();
                this.closeConflictModal();
            }
        });
    }

    // Navigation methods
    navigate(direction) {
        switch (this.currentView) {
            case 'monthly':
                this.currentDate.setMonth(this.currentDate.getMonth() + direction);
                break;
            case 'weekly':
                this.currentDate.setDate(this.currentDate.getDate() + (direction * 7));
                break;
            case 'daily':
                this.currentDate.setDate(this.currentDate.getDate() + direction);
                break;
        }
        this.updateCurrentDateDisplay();
        this.renderCurrentView();
    }

    // View switching
    switchView(view) {
        this.currentView = view;

        // Update active button
        document.querySelectorAll('.view-btn').forEach(btn => btn.classList.remove('active'));
        document.getElementById(view + 'View').classList.add('active');

        // Update active view
        document.querySelectorAll('.view-container').forEach(container => container.classList.remove('active'));
        document.getElementById(view + 'View').classList.add('active');

        this.renderCurrentView();
    }

    // Update current date display
    updateCurrentDateDisplay() {
        const options = {
            year: 'numeric',
            month: 'long',
            day: this.currentView === 'daily' ? 'numeric' : undefined
        };
        document.getElementById('currentDate').textContent = this.currentDate.toLocaleDateString('en-US', options);
    }

    // Render current view
    renderCurrentView() {
        switch (this.currentView) {
            case 'monthly':
                this.renderMonthlyView();
                break;
            case 'weekly':
                this.renderWeeklyView();
                break;
            case 'daily':
                this.renderDailyView();
                break;
            case 'agenda':
                this.renderAgendaView();
                break;
        }
    }

    // Monthly View
    renderMonthlyView() {
        const monthGrid = document.getElementById('monthGrid');
        monthGrid.innerHTML = '';

        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();

        // Get first day of month and number of days
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startDay = firstDay.getDay();

        // Previous month days
        const prevMonth = new Date(year, month - 1, 0);
        for (let i = startDay - 1; i >= 0; i--) {
            const day = prevMonth.getDate() - i;
            const dayCell = this.createDayCell(day, true, new Date(year, month - 1, day));
            monthGrid.appendChild(dayCell);
        }

        // Current month days
        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(year, month, day);
            const dayCell = this.createDayCell(day, false, date);
            monthGrid.appendChild(dayCell);
        }

        // Next month days
        const totalCells = monthGrid.children.length;
        const remainingCells = 42 - totalCells; // 6 weeks * 7 days
        for (let day = 1; day <= remainingCells; day++) {
            const dayCell = this.createDayCell(day, true, new Date(year, month + 1, day));
            monthGrid.appendChild(dayCell);
        }
    }

    createDayCell(day, isOtherMonth, date) {
        const dayCell = document.createElement('div');
        dayCell.className = 'day-cell';

        if (isOtherMonth) {
            dayCell.classList.add('other-month');
        }

        if (this.isToday(date)) {
            dayCell.classList.add('today');
        }

        if (this.isWeekend(date)) {
            dayCell.classList.add('weekend');
        }

        if (this.isHoliday(date)) {
            dayCell.classList.add('holiday');
        }

        const dayNumber = document.createElement('div');
        dayNumber.className = 'day-number';
        dayNumber.textContent = day;
        dayCell.appendChild(dayNumber);

        // Add events for this day
        const dayEvents = this.getEventsForDate(date);
        dayEvents.forEach(event => {
            const eventSnippet = document.createElement('div');
            eventSnippet.className = 'event-snippet';
            eventSnippet.textContent = event.title;
            eventSnippet.style.backgroundColor = this.categories[event.category]?.color || '#007bff';
            eventSnippet.addEventListener('click', (e) => {
                e.stopPropagation();
                this.editEvent(event);
            });
            dayCell.appendChild(eventSnippet);
        });

        dayCell.addEventListener('click', () => {
            this.currentDate = new Date(date);
            this.switchView('daily');
        });

        return dayCell;
    }

    // Weekly View
    renderWeeklyView() {
        const weekDays = document.getElementById('weekDays');
        const weekGrid = document.getElementById('weekGrid');

        weekDays.innerHTML = '';
        weekGrid.innerHTML = '';

        // Get start of week (Sunday)
        const startOfWeek = new Date(this.currentDate);
        startOfWeek.setDate(this.currentDate.getDate() - this.currentDate.getDay());

        // Create day headers
        for (let i = 0; i < 7; i++) {
            const dayDate = new Date(startOfWeek);
            dayDate.setDate(startOfWeek.getDate() + i);

            const dayHeader = document.createElement('div');
            dayHeader.className = 'week-day-header';
            dayHeader.innerHTML = `
                <div>${dayDate.toLocaleDateString('en-US', { weekday: 'short' })}</div>
                <div>${dayDate.getDate()}</div>
            `;
            weekDays.appendChild(dayHeader);

            // Create day column
            const dayColumn = document.createElement('div');
            dayColumn.className = 'day-column';
            dayColumn.addEventListener('click', () => {
                this.currentDate = new Date(dayDate);
                this.switchView('daily');
            });

            // Add events for this day
            const dayEvents = this.getEventsForDate(dayDate);
            dayEvents.forEach(event => {
                const eventItem = this.createEventItem(event);
                dayColumn.appendChild(eventItem);
            });

            weekGrid.appendChild(dayColumn);
        }
    }

    // Daily View
    renderDailyView() {
        const currentDay = document.getElementById('currentDay');
        const dayGrid = document.getElementById('dayGrid');

        currentDay.textContent = this.currentDate.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        dayGrid.innerHTML = '';

        // Add events for this day
        const dayEvents = this.getEventsForDate(this.currentDate);
        dayEvents.sort((a, b) => new Date(a.startTime) - new Date(b.startTime));

        dayEvents.forEach(event => {
            const eventItem = this.createEventItem(event);
            dayGrid.appendChild(eventItem);
        });
    }

    // Agenda View
    renderAgendaView() {
        const agendaList = document.getElementById('agendaList');
        agendaList.innerHTML = '';

        // Get all future events
        const futureEvents = this.events.filter(event => {
            const eventDate = new Date(event.startTime);
            return eventDate >= new Date();
        });

        // Group events by date
        const eventsByDate = {};
        futureEvents.forEach(event => {
            const date = new Date(event.startTime).toDateString();
            if (!eventsByDate[date]) {
                eventsByDate[date] = [];
            }
            eventsByDate[date].push(event);
        });

        // Sort dates
        const sortedDates = Object.keys(eventsByDate).sort((a, b) => new Date(a) - new Date(b));

        sortedDates.forEach(dateStr => {
            const date = new Date(dateStr);
            const dayEvents = eventsByDate[dateStr].sort((a, b) => new Date(a.startTime) - new Date(b.startTime));

            dayEvents.forEach(event => {
                const agendaItem = document.createElement('div');
                agendaItem.className = 'agenda-item';
                agendaItem.innerHTML = `
                    <div class="agenda-date">
                        <div>${date.toLocaleDateString('en-US', { month: 'short' })}</div>
                        <div>${date.getDate()}</div>
                    </div>
                    <div class="agenda-time">
                        ${new Date(event.startTime).toLocaleTimeString('en-US', {
                    hour: 'numeric',
                    minute: '2-digit',
                    hour12: true
                })}
                    </div>
                    <div class="agenda-details">
                        <div class="agenda-title">${event.title}</div>
                        ${event.description ? `<div class="agenda-description">${event.description}</div>` : ''}
                    </div>
                `;
                agendaItem.addEventListener('click', () => this.editEvent(event));
                agendaList.appendChild(agendaItem);
            });
        });

        if (futureEvents.length === 0) {
            agendaList.innerHTML = '<div style="text-align: center; padding: 2rem; color: #6c757d;">No upcoming events</div>';
        }
    }

    // Event management
    createEventItem(event) {
        const eventItem = document.createElement('div');
        eventItem.className = 'event-item';
        eventItem.style.backgroundColor = this.categories[event.category]?.color || '#007bff';
        eventItem.innerHTML = `
            <div style="font-weight: 600;">${event.title}</div>
            <div style="font-size: 0.8rem; opacity: 0.9;">
                ${new Date(event.startTime).toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        })} - ${new Date(event.endTime).toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        })}
            </div>
        `;
        eventItem.addEventListener('click', () => this.editEvent(event));
        return eventItem;
    }

    openEventModal(event = null) {
        this.editingEvent = event;
        const modal = document.getElementById('eventModal');
        const modalTitle = document.getElementById('modalTitle');
        const deleteBtn = document.getElementById('deleteEvent');

        if (event) {
            modalTitle.textContent = 'Edit Event';
            deleteBtn.style.display = 'block';
            this.populateEventForm(event);
        } else {
            modalTitle.textContent = 'Add Event';
            deleteBtn.style.display = 'none';
            this.clearEventForm();
            this.setDefaultTimes();
        }

        modal.classList.add('show');
    }

    closeEventModal() {
        document.getElementById('eventModal').classList.remove('show');
        this.editingEvent = null;
    }

    populateEventForm(event) {
        document.getElementById('eventTitle').value = event.title;
        document.getElementById('eventDescription').value = event.description || '';
        document.getElementById('eventStartDate').value = new Date(event.startTime).toISOString().split('T')[0];
        document.getElementById('eventStartTime').value = new Date(event.startTime).toTimeString().slice(0, 5);
        document.getElementById('eventEndDate').value = new Date(event.endTime).toISOString().split('T')[0];
        document.getElementById('eventEndTime').value = new Date(event.endTime).toTimeString().slice(0, 5);
        document.getElementById('eventCategory').value = event.category;
        document.getElementById('isRecurring').checked = event.isRecurring || false;
        document.getElementById('recurringWeeks').value = event.recurringWeeks || 4;
        document.getElementById('recurringWeeks').disabled = !event.isRecurring;
    }

    clearEventForm() {
        document.getElementById('eventForm').reset();
    }

    setDefaultTimes() {
        const now = new Date();
        const startTime = new Date(now.getTime() + 60 * 60 * 1000); // 1 hour from now
        const endTime = new Date(startTime.getTime() + 60 * 60 * 1000); // 2 hours from now

        document.getElementById('eventStartDate').value = startTime.toISOString().split('T')[0];
        document.getElementById('eventStartTime').value = startTime.toTimeString().slice(0, 5);
        document.getElementById('eventEndDate').value = endTime.toISOString().split('T')[0];
        document.getElementById('eventEndTime').value = endTime.toTimeString().slice(0, 5);
    }

    handleEventSubmit(e) {
        e.preventDefault();

        const formData = {
            title: document.getElementById('eventTitle').value,
            description: document.getElementById('eventDescription').value,
            startDate: document.getElementById('eventStartDate').value,
            startTime: document.getElementById('eventStartTime').value,
            endDate: document.getElementById('eventEndDate').value,
            endTime: document.getElementById('eventEndTime').value,
            category: document.getElementById('eventCategory').value,
            isRecurring: document.getElementById('isRecurring').checked,
            recurringWeeks: parseInt(document.getElementById('recurringWeeks').value)
        };

        const startDateTime = new Date(`${formData.startDate}T${formData.startTime}`);
        const endDateTime = new Date(`${formData.endDate}T${formData.endTime}`);

        if (endDateTime <= startDateTime) {
            alert('End time must be after start time');
            return;
        }

        // Check for conflicts
        const conflicts = this.checkTimeConflicts(startDateTime, endDateTime, this.editingEvent?.id);

        if (conflicts.length > 0) {
            this.showConflictModal(conflicts, formData);
            return;
        }

        this.saveEvent(formData);
    }

    checkTimeConflicts(startTime, endTime, excludeEventId = null) {
        return this.events.filter(event => {
            if (event.id === excludeEventId) return false;

            const eventStart = new Date(event.startTime);
            const eventEnd = new Date(event.endTime);

            return (startTime < eventEnd && endTime > eventStart);
        });
    }

    showConflictModal(conflicts, formData) {
        const conflictList = document.getElementById('conflictList');
        conflictList.innerHTML = '';

        conflicts.forEach(conflict => {
            const conflictItem = document.createElement('div');
            conflictItem.className = 'conflict-item';
            conflictItem.innerHTML = `
                <strong>${conflict.title}</strong><br>
                ${new Date(conflict.startTime).toLocaleString()} - ${new Date(conflict.endTime).toLocaleString()}
            `;
            conflictList.appendChild(conflictItem);
        });

        this.pendingEventData = formData;
        document.getElementById('conflictModal').classList.add('show');
    }

    proceedWithConflict() {
        this.saveEvent(this.pendingEventData);
        this.closeConflictModal();
    }

    closeConflictModal() {
        document.getElementById('conflictModal').classList.remove('show');
        this.pendingEventData = null;
    }

    saveEvent(formData) {
        const startDateTime = new Date(`${formData.startDate}T${formData.startTime}`);
        const endDateTime = new Date(`${formData.endDate}T${formData.endTime}`);

        if (this.editingEvent) {
            // Update existing event
            const eventIndex = this.events.findIndex(e => e.id === this.editingEvent.id);
            if (eventIndex !== -1) {
                this.events[eventIndex] = {
                    ...this.events[eventIndex],
                    title: formData.title,
                    description: formData.description,
                    startTime: startDateTime.toISOString(),
                    endTime: endDateTime.toISOString(),
                    category: formData.category,
                    isRecurring: formData.isRecurring,
                    recurringWeeks: formData.recurringWeeks
                };
            }
        } else {
            // Create new event
            const newEvent = {
                id: Date.now().toString(),
                title: formData.title,
                description: formData.description,
                startTime: startDateTime.toISOString(),
                endTime: endDateTime.toISOString(),
                category: formData.category,
                isRecurring: formData.isRecurring,
                recurringWeeks: formData.recurringWeeks
            };

            this.events.push(newEvent);

            // Add recurring events if needed
            if (formData.isRecurring) {
                for (let i = 1; i < formData.recurringWeeks; i++) {
                    const recurringStart = new Date(startDateTime);
                    const recurringEnd = new Date(endDateTime);
                    recurringStart.setDate(recurringStart.getDate() + (i * 7));
                    recurringEnd.setDate(recurringEnd.getDate() + (i * 7));

                    this.events.push({
                        ...newEvent,
                        id: `${newEvent.id}_${i}`,
                        startTime: recurringStart.toISOString(),
                        endTime: recurringEnd.toISOString()
                    });
                }
            }
        }

        this.saveEvents();
        this.closeEventModal();
        this.renderCurrentView();
    }

    editEvent(event) {
        this.openEventModal(event);
    }

    deleteCurrentEvent() {
        if (this.editingEvent && confirm('Are you sure you want to delete this event?')) {
            this.events = this.events.filter(e => e.id !== this.editingEvent.id);
            this.saveEvents();
            this.closeEventModal();
            this.renderCurrentView();
        }
    }

    // Categories management
    openCategoriesModal() {
        document.getElementById('categoriesModal').classList.add('show');
        this.renderCategories();
    }

    closeCategoriesModal() {
        document.getElementById('categoriesModal').classList.remove('show');
    }

    renderCategories() {
        const categoriesList = document.getElementById('categoriesList');
        categoriesList.innerHTML = '';

        Object.entries(this.categories).forEach(([name, category]) => {
            if (name === 'general') return; // Don't show default category

            const categoryItem = document.createElement('div');
            categoryItem.className = 'category-item';
            categoryItem.innerHTML = `
                <div class="category-color" style="background-color: ${category.color}"></div>
                <div class="category-name">${name}</div>
                <button class="delete-category" onclick="calendarApp.deleteCategory('${name}')">Delete</button>
            `;
            categoriesList.appendChild(categoryItem);
        });
    }

    addCategory() {
        const name = document.getElementById('newCategoryName').value.trim();
        const color = document.getElementById('newCategoryColor').value;

        if (!name) {
            alert('Please enter a category name');
            return;
        }

        if (this.categories[name]) {
            alert('Category already exists');
            return;
        }

        this.categories[name] = { color };
        this.saveCategories();
        this.populateCategories();
        this.renderCategories();

        document.getElementById('newCategoryName').value = '';
        document.getElementById('newCategoryColor').value = '#007bff';
    }

    deleteCategory(name) {
        if (confirm(`Are you sure you want to delete the "${name}" category?`)) {
            delete this.categories[name];
            this.saveCategories();
            this.populateCategories();
            this.renderCategories();
        }
    }

    populateCategories() {
        const categorySelect = document.getElementById('eventCategory');
        categorySelect.innerHTML = '';

        Object.keys(this.categories).forEach(name => {
            const option = document.createElement('option');
            option.value = name;
            option.textContent = name.charAt(0).toUpperCase() + name.slice(1);
            categorySelect.appendChild(option);
        });
    }

    // Utility methods
    getEventsForDate(date) {
        const dateStr = date.toDateString();
        return this.events.filter(event => {
            const eventDate = new Date(event.startTime).toDateString();
            return eventDate === dateStr;
        });
    }

    isToday(date) {
        const today = new Date();
        return date.toDateString() === today.toDateString();
    }

    isWeekend(date) {
        const day = date.getDay();
        return day === 0 || day === 6; // Sunday or Saturday
    }

    isHoliday(date) {
        // Simple holiday check - you can expand this
        const month = date.getMonth();
        const day = date.getDate();

        // New Year's Day
        if (month === 0 && day === 1) return true;
        // Independence Day
        if (month === 6 && day === 4) return true;
        // Christmas
        if (month === 11 && day === 25) return true;

        return false;
    }

    loadHolidays() {
        // You can expand this to load holidays from an API or more comprehensive list
    }

    populateTimeSlots() {
        const timeSlots = document.querySelectorAll('.time-slots');
        timeSlots.forEach(container => {
            container.innerHTML = '';
            for (let hour = 0; hour < 24; hour++) {
                const timeSlot = document.createElement('div');
                timeSlot.className = 'time-slot';
                timeSlot.textContent = hour === 0 ? '12 AM' :
                    hour < 12 ? `${hour} AM` :
                        hour === 12 ? '12 PM' : `${hour - 12} PM`;
                container.appendChild(timeSlot);
            }
        });
    }

    // Data persistence
    saveEvents() {
        localStorage.setItem('calendarEvents', JSON.stringify(this.events));
    }

    loadEvents() {
        const saved = localStorage.getItem('calendarEvents');
        return saved ? JSON.parse(saved) : [];
    }

    saveCategories() {
        localStorage.setItem('calendarCategories', JSON.stringify(this.categories));
    }

    loadCategories() {
        const saved = localStorage.getItem('calendarCategories');
        return saved ? JSON.parse(saved) : {
            general: { color: '#007bff' },
            work: { color: '#28a745' },
            personal: { color: '#ffc107' },
            health: { color: '#dc3545' }
        };
    }
}

// Initialize the calendar app when the page loads
let calendarApp;
document.addEventListener('DOMContentLoaded', () => {
    calendarApp = new CalendarApp();
});


